from graphics import *
from random import *
class Player:

    def __init__(self,name):

        self.name = name

        #Create Chip Types(White, Blue, Green, Red, Black)
        self.chips = {"White":[5,10],"Blue":[10,10],"Red":[20,10],"Green":[50,10],"Black":[100,10]}

        self.cards = {}
        self.cardGraphs = []

    #things = {"card1":["circle",100,100,200],"card2":["square",100,100,200,200]}
    #Try using dictionaries to create store the cards. ^^^

    def generateCard(self,cardNum):
        value = ['2','3','4','5','6','7','8','9','10','King','Queen','Jack','Ace']
        pattern = ['Diamonds','Clubs','Hearts','Spades']
        self.card = []
        self.cardValue = value[randint(0,12)]
        self.cardPattern = pattern[randint(0,3)]
        self.card.append(self.cardValue)
        self.card.append(self.cardPattern)
        self.cards[str(cardNum)] = self.card

    def assignCard(self,cardNum):
        if self.cards[str(cardNum)][0] == '2':
                if self.cards[str(cardNum)][1] == 'Diamonds':
                    self.cardGraphs.append("2_of_diamonds.gif")

                elif self.cards[str(cardNum)][1] == 'Clubs':
                    self.cardGraphs.append("2_of_clubs.gif")

                elif self.cards[str(cardNum)][1] == 'Hearts':
                    self.cardGraphs.append("2_of_hearts.gif")

                elif self.cards[str(cardNum)][1] == 'Spades':
                    self.cardGraphs.append("2_of_spades.gif")
                else:
                    print("Something went wrong in printCard subsec")
                
        elif self.cards[str(cardNum)][0] == '3':
                if self.cards[str(cardNum)][1] == 'Diamonds':
                    self.cardGraphs.append("3_of_diamonds.gif")

                elif self.cards[str(cardNum)][1] == 'Clubs':
                    self.cardGraphs.append("3_of_clubs.gif")

                elif self.cards[str(cardNum)][1] == 'Hearts':
                    self.cardGraphs.append("3_of_hearts.gif")

                elif self.cards[str(cardNum)][1] == 'Spades':
                    self.cardGraphs.append("3_of_spades.gif")
                else:
                    print("Something went wrong in printCard subsec")
                
        elif self.cards[str(cardNum)][0] == '4':
                if self.cards[str(cardNum)][1] == 'Diamonds':
                    self.cardGraphs.append("4_of_diamonds.gif")

                elif self.cards[str(cardNum)][1] == 'Clubs':
                    self.cardGraphs.append("4_of_clubs.gif")

                elif self.cards[str(cardNum)][1] == 'Hearts':
                    self.cardGraphs.append("4_of_hearts.gif")

                elif self.cards[str(cardNum)][1] == 'Spades':
                    self.cardGraphs.append("4_of_spades.gif")
                else:
                    print("Something went wrong in printCard subsec")                

        elif self.cards[str(cardNum)][0] == '5':
                if self.cards[str(cardNum)][1] == 'Diamonds':
                    self.cardGraphs.append("5_of_diamonds.gif")

                elif self.cards[str(cardNum)][1] == 'Clubs':
                    self.cardGraphs.append("5_of_clubs.gif")

                elif self.cards[str(cardNum)][1] == 'Hearts':
                    self.cardGraphs.append("5_of_hearts.gif")

                elif self.cards[str(cardNum)][1] == 'Spades':
                    self.cardGraphs.append("5_of_spades.gif")
                else:
                    print("Something went wrong in printCard subsec")                

                
        elif self.cards[str(cardNum)][0] == '6':
                if self.cards[str(cardNum)][1] == 'Diamonds':
                    self.cardGraphs.append("6_of_diamonds.gif")

                elif self.cards[str(cardNum)][1] == 'Clubs':
                    self.cardGraphs.append("6_of_clubs.gif")

                elif self.cards[str(cardNum)][1] == 'Hearts':
                    self.cardGraphs.append("6_of_hearts.gif")

                elif self.cards[str(cardNum)][1] == 'Spades':
                    self.cardGraphs.append("6_of_spades.gif")
                else:
                    print("Something went wrong in printCard subsec")                

                
        elif self.cards[str(cardNum)][0] == '7':
                if self.cards[str(cardNum)][1] == 'Diamonds':
                    self.cardGraphs.append("7_of_diamonds.gif")

                elif self.cards[str(cardNum)][1] == 'Clubs':
                    self.cardGraphs.append("7_of_clubs.gif")

                elif self.cards[str(cardNum)][1] == 'Hearts':
                    self.cardGraphs.append("7_of_hearts.gif")

                elif self.cards[str(cardNum)][1] == 'Spades':
                    self.cardGraphs.append("7_of_spades.gif")
                else:
                    print("Something went wrong in printCard subsec")                

                
        elif self.cards[str(cardNum)][0] == '8':
                if self.cards[str(cardNum)][1] == 'Diamonds':
                    self.cardGraphs.append("8_of_diamonds.gif")

                elif self.cards[str(cardNum)][1] == 'Clubs':
                    self.cardGraphs.append("8_of_clubs.gif")

                elif self.cards[str(cardNum)][1] == 'Hearts':
                    self.cardGraphs.append("8_of_hearts.gif")

                elif self.cards[str(cardNum)][1] == 'Spades':
                    self.cardGraphs.append("8_of_spades.gif")
                else:
                    print("Something went wrong in printCard subsec")                

                
        elif self.cards[str(cardNum)][0] == '9':
                if self.cards[str(cardNum)][1] == 'Diamonds':
                    self.cardGraphs.append("9_of_diamonds.gif")

                elif self.cards[str(cardNum)][1] == 'Clubs':
                    self.cardGraphs.append("9_of_clubs.gif")

                elif self.cards[str(cardNum)][1] == 'Hearts':
                    self.cardGraphs.append("9_of_hearts.gif")

                elif self.cards[str(cardNum)][1] == 'Spades':
                    self.cardGraphs.append("9_of_spades.gif")
                else:
                    print("Something went wrong in printCard subsec")                

                
        elif self.cards[str(cardNum)][0] == '10':
                if self.cards[str(cardNum)][1] == 'Diamonds':
                    self.cardGraphs.append("10_of_diamonds.gif")

                elif self.cards[str(cardNum)][1] == 'Clubs':
                    self.cardGraphs.append("10_of_clubs.gif")

                elif self.cards[str(cardNum)][1] == 'Hearts':
                    self.cardGraphs.append("10_of_hearts.gif")

                elif self.cards[str(cardNum)][1] == 'Spades':
                    self.cardGraphs.append("10_of_spades.gif")
                else:
                    print("Something went wrong in printCard subsec")                


        elif self.cards[str(cardNum)][0] == 'King':
                if self.cards[str(cardNum)][1] == 'Diamonds':
                    self.cardGraphs.append("king_of_diamonds2.gif")

                elif self.cards[str(cardNum)][1] == 'Clubs':
                    self.cardGraphs.append("king_of_clubs2.gif")

                elif self.cards[str(cardNum)][1] == 'Hearts':
                    self.cardGraphs.append("king_of_hearts2.gif")

                elif self.cards[str(cardNum)][1] == 'Spades':
                    self.cardGraphs.append("king_of_spades2.gif")

                else:
                    print("Something went wrong in printCard subsec")

        elif self.cards[str(cardNum)][0] == 'Queen':
                if self.cards[str(cardNum)][1] == 'Diamonds':
                    self.cardGraphs.append("queen_of_diamonds2.gif")
                    
                elif self.cards[str(cardNum)][1] == 'Clubs':
                    self.cardGraphs.append("queen_of_clubs2.gif")

                elif self.cards[str(cardNum)][1] == 'Hearts':
                    self.cardGraphs.append("queen_of_hearts2.gif")

                elif self.cards[str(cardNum)][1] == 'Spades':
                    self.cardGraphs.append("queen_of_spades2.gif")

                else:
                    print("Something went wrong in printCard subsec")

        elif self.cards[str(cardNum)][0] == 'Jack':
                if self.cards[str(cardNum)][1] == 'Diamonds':
                    self.cardGraphs.append("jack_of_diamonds2.gif")
                    
                elif self.cards[str(cardNum)][1] == 'Clubs':
                    self.cardGraphs.append("jack_of_clubs2.gif")

                elif self.cards[str(cardNum)][1] == 'Hearts':
                    self.cardGraphs.append("jack_of_hearts2.gif")

                elif self.cards[str(cardNum)][1] == 'Spades':
                    self.cardGraphs.append("jack_of_spades2.gif")

                else:
                    print("Something went wrong in printCard subsec")

        elif self.cards[str(cardNum)][0] == 'Ace':
                if self.cards[str(cardNum)][1] == 'Diamonds':
                    self.cardGraphs.append("ace_of_diamonds.gif")

                elif self.cards[str(cardNum)][1] == 'Clubs':
                    self.cardGraphs.append("ace_of_clubs.gif")

                elif self.cards[str(cardNum)][1] == 'Hearts':
                    self.cardGraphs.append("ace_of_hearts.gif")

                elif self.cards[str(cardNum)][1] == 'Spades':
                    self.cardGraphs.append("ace_of_spades2.gif")

                else:
                    print("Something went wrong in printCard subsec")

        else:
                print("Something went wrong in printCard Red")

    def clearCard(self):
        self.cards = {}
        self.cardGraphs = []

   #Get the value of the chip by typing the color and the index position (Position 0 is the value of each chip, Position 1 is the total amount of chips. getVal returns the total $$ amount of those chips
    def getVal(self,chipType):
        value = "$" + str(self.chips[chipType][0] * self.chips[chipType][1])
        return value
    
       
class TableCards: #Create the table cards (Should be Five each hand, and should be very similar to generateCard)

    def __init__(self,roundNum):
        self.roundNum = roundNum
        self.cards = {}
        self.cardGraphs = []
        
        
    def generateTableCard(self,cardNum):
        value = ['2','3','4','5','6','7','8','9','10','King','Queen','Jack','Ace']
        pattern = ['Diamonds','Clubs','Hearts','Spades']

        self.card = []
        self.cardValue = value[randint(0,12)]
        self.cardPattern = pattern[randint(0,3)]
        self.card.append(self.cardValue)
        self.card.append(self.cardPattern)
        self.cards[str(cardNum)] = self.card

    def assignCard(self,cardNum):
        if self.cards[str(cardNum)][0] == '2':
                if self.cards[str(cardNum)][1] == 'Diamonds':
                    self.cardGraphs.append("2_of_diamonds.gif")

                elif self.cards[str(cardNum)][1] == 'Clubs':
                    self.cardGraphs.append("2_of_clubs.gif")

                elif self.cards[str(cardNum)][1] == 'Hearts':
                    self.cardGraphs.append("2_of_hearts.gif")

                elif self.cards[str(cardNum)][1] == 'Spades':
                    self.cardGraphs.append("2_of_spades.gif")
                else:
                    print("Something went wrong in printCard subsec")
                
        elif self.cards[str(cardNum)][0] == '3':
                if self.cards[str(cardNum)][1] == 'Diamonds':
                    self.cardGraphs.append("3_of_diamonds.gif")

                elif self.cards[str(cardNum)][1] == 'Clubs':
                    self.cardGraphs.append("3_of_clubs.gif")

                elif self.cards[str(cardNum)][1] == 'Hearts':
                    self.cardGraphs.append("3_of_hearts.gif")

                elif self.cards[str(cardNum)][1] == 'Spades':
                    self.cardGraphs.append("3_of_spades.gif")
                else:
                    print("Something went wrong in printCard subsec")
                
        elif self.cards[str(cardNum)][0] == '4':
                if self.cards[str(cardNum)][1] == 'Diamonds':
                    self.cardGraphs.append("4_of_diamonds.gif")

                elif self.cards[str(cardNum)][1] == 'Clubs':
                    self.cardGraphs.append("4_of_clubs.gif")

                elif self.cards[str(cardNum)][1] == 'Hearts':
                    self.cardGraphs.append("4_of_hearts.gif")

                elif self.cards[str(cardNum)][1] == 'Spades':
                    self.cardGraphs.append("4_of_spades.gif")
                else:
                    print("Something went wrong in printCard subsec")                

        elif self.cards[str(cardNum)][0] == '5':
                if self.cards[str(cardNum)][1] == 'Diamonds':
                    self.cardGraphs.append("5_of_diamonds.gif")

                elif self.cards[str(cardNum)][1] == 'Clubs':
                    self.cardGraphs.append("5_of_clubs.gif")

                elif self.cards[str(cardNum)][1] == 'Hearts':
                    self.cardGraphs.append("5_of_hearts.gif")

                elif self.cards[str(cardNum)][1] == 'Spades':
                    self.cardGraphs.append("5_of_spades.gif")
                else:
                    print("Something went wrong in printCard subsec")                

                
        elif self.cards[str(cardNum)][0] == '6':
                if self.cards[str(cardNum)][1] == 'Diamonds':
                    self.cardGraphs.append("6_of_diamonds.gif")

                elif self.cards[str(cardNum)][1] == 'Clubs':
                    self.cardGraphs.append("6_of_clubs.gif")

                elif self.cards[str(cardNum)][1] == 'Hearts':
                    self.cardGraphs.append("6_of_hearts.gif")

                elif self.cards[str(cardNum)][1] == 'Spades':
                    self.cardGraphs.append("6_of_spades.gif")
                else:
                    print("Something went wrong in printCard subsec")                

                
        elif self.cards[str(cardNum)][0] == '7':
                if self.cards[str(cardNum)][1] == 'Diamonds':
                    self.cardGraphs.append("7_of_diamonds.gif")

                elif self.cards[str(cardNum)][1] == 'Clubs':
                    self.cardGraphs.append("7_of_clubs.gif")

                elif self.cards[str(cardNum)][1] == 'Hearts':
                    self.cardGraphs.append("7_of_hearts.gif")

                elif self.cards[str(cardNum)][1] == 'Spades':
                    self.cardGraphs.append("7_of_spades.gif")
                else:
                    print("Something went wrong in printCard subsec")                

                
        elif self.cards[str(cardNum)][0] == '8':
                if self.cards[str(cardNum)][1] == 'Diamonds':
                    self.cardGraphs.append("8_of_diamonds.gif")

                elif self.cards[str(cardNum)][1] == 'Clubs':
                    self.cardGraphs.append("8_of_clubs.gif")

                elif self.cards[str(cardNum)][1] == 'Hearts':
                    self.cardGraphs.append("8_of_hearts.gif")

                elif self.cards[str(cardNum)][1] == 'Spades':
                    self.cardGraphs.append("8_of_spades.gif")
                else:
                    print("Something went wrong in printCard subsec")                

                
        elif self.cards[str(cardNum)][0] == '9':
                if self.cards[str(cardNum)][1] == 'Diamonds':
                    self.cardGraphs.append("9_of_diamonds.gif")

                elif self.cards[str(cardNum)][1] == 'Clubs':
                    self.cardGraphs.append("9_of_clubs.gif")

                elif self.cards[str(cardNum)][1] == 'Hearts':
                    self.cardGraphs.append("9_of_hearts.gif")

                elif self.cards[str(cardNum)][1] == 'Spades':
                    self.cardGraphs.append("9_of_spades.gif")
                else:
                    print("Something went wrong in printCard subsec")                

                
        elif self.cards[str(cardNum)][0] == '10':
                if self.cards[str(cardNum)][1] == 'Diamonds':
                    self.cardGraphs.append("10_of_diamonds.gif")

                elif self.cards[str(cardNum)][1] == 'Clubs':
                    self.cardGraphs.append("10_of_clubs.gif")

                elif self.cards[str(cardNum)][1] == 'Hearts':
                    self.cardGraphs.append("10_of_hearts.gif")

                elif self.cards[str(cardNum)][1] == 'Spades':
                    self.cardGraphs.append("10_of_spades.gif")
                else:
                    print("Something went wrong in printCard subsec")                


        elif self.cards[str(cardNum)][0] == 'King':
                if self.cards[str(cardNum)][1] == 'Diamonds':
                    self.cardGraphs.append("king_of_diamonds2.gif")

                elif self.cards[str(cardNum)][1] == 'Clubs':
                    self.cardGraphs.append("king_of_clubs2.gif")

                elif self.cards[str(cardNum)][1] == 'Hearts':
                    self.cardGraphs.append("king_of_hearts2.gif")

                elif self.cards[str(cardNum)][1] == 'Spades':
                    self.cardGraphs.append("king_of_spades2.gif")

                else:
                    print("Something went wrong in printCard subsec")

        elif self.cards[str(cardNum)][0] == 'Queen':
                if self.cards[str(cardNum)][1] == 'Diamonds':
                    self.cardGraphs.append("queen_of_diamonds2.gif")
                    
                elif self.cards[str(cardNum)][1] == 'Clubs':
                    self.cardGraphs.append("queen_of_clubs2.gif")

                elif self.cards[str(cardNum)][1] == 'Hearts':
                    self.cardGraphs.append("queen_of_hearts2.gif")

                elif self.cards[str(cardNum)][1] == 'Spades':
                    self.cardGraphs.append("queen_of_spades2.gif")

                else:
                    print("Something went wrong in printCard subsec")

        elif self.cards[str(cardNum)][0] == 'Jack':
                if self.cards[str(cardNum)][1] == 'Diamonds':
                    self.cardGraphs.append("jack_of_diamonds2.gif")
                    
                elif self.cards[str(cardNum)][1] == 'Clubs':
                    self.cardGraphs.append("jack_of_clubs2.gif")

                elif self.cards[str(cardNum)][1] == 'Hearts':
                    self.cardGraphs.append("jack_of_hearts2.gif")

                elif self.cards[str(cardNum)][1] == 'Spades':
                    self.cardGraphs.append("jack_of_spades2.gif")

                else:
                    print("Something went wrong in printCard subsec")

        elif self.cards[str(cardNum)][0] == 'Ace':
                if self.cards[str(cardNum)][1] == 'Diamonds':
                    self.cardGraphs.append("ace_of_diamonds.gif")

                elif self.cards[str(cardNum)][1] == 'Clubs':
                    self.cardGraphs.append("ace_of_clubs.gif")

                elif self.cards[str(cardNum)][1] == 'Hearts':
                    self.cardGraphs.append("ace_of_hearts.gif")

                elif self.cards[str(cardNum)][1] == 'Spades':
                    self.cardGraphs.append("ace_of_spades2.gif")

                else:
                    print("Something went wrong in printCard subsec")

        else:
                print("Something went wrong in printCard Red")

    def clearCard(self):
        self.cards = {}
        self.cardGraphs = []

def main():
    player1 = Player("Jimmy")
    player1.generateCard(1)
    player1.generateCard(2)
    player1.assignCard(1)
    player1.assignCard(2)
    player1.cardGraphs
    card1Name = player1.cardGraphs[0]
    card2Name = player1.cardGraphs[1]
    win = GraphWin("Player 1 Cards",1000,1000)
    card1 = Image(Point(250,400),card1Name)
    card1.draw(win)
    card2 = Image(Point(750,400),card2Name)
    card2.draw(win)    
main()


def tableCards():
    tableCards = TableCards(1)
    tableCards.generateTableCard(1)
    tableCards.generateTableCard(2)
    tableCards.generateTableCard(3)
    tableCards.assignCard(1)
    tableCards.assignCard(2)
    tableCards.assignCard(3)
    card1Name = tableCards.cardGraphs[0]
    card2Name = tableCards.cardGraphs[1]
    card3Name = tableCards.cardGraphs[2]
    win = GraphWin("TableCards",1000,1000)
    card1 = Image(Point(300,300),card1Name)
    card1.draw(win)
    card2 = Image(Point(600,300),card2Name)
    card2.draw(win)
    card3 = Image(Point(900,300),card3Name)
    card3.draw(win)
tableCards()
