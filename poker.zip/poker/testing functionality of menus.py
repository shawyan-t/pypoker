from graphics import *
def crab():
    print("heater")
    
def main():
    win = GraphWin("testing ",400,400)
    Rectangle(Point(100,100),Point(300,300)).draw(win)
    # mouse = win.getMouse()
    needsToChange = 0
    while(needsToChange == 0):
        mouse = win.getMouse()
        if mouse.getX() > 100 and mouse.getX() < 300 and mouse.getY() > 100 and mouse.getY() < 300:
            # needsToChange = 3
            crab()
            continue
        else:
            needsToChange = 0
            print("jar")
            
main()
