#if player chip amount = 0
    #remove from list
#if length of list = 1
    #print winning message
    #write to file the winner , time, and date
    #go to main menu


theList = ["jimmy","james","john","jones"]
theList.pop(1)
print(theList)
