#INPUT: User's name, amount of players

#PROCESS: Display the graphics window, register where their mouse clicks
#PROCESS: for gameplay aspects of poker, assign value to chip amount, sort hands
#PROCESS: by hierarchy (who wins round), write files to a folder at the end of
#PROCESS: a game.

#OUTPUT: A graphics window with a functioning poker game, and a file written to
#OUTPUT: a folder at the end of the game.

#Import required modules (graphics, random , and timedate) 
from graphics import *
from random import *
from datetime import *

#---------------------------------------------------------------------------------PLAYER CLASS----------------------------------------------------------------------------
#Description: Creates the player class
class Player:

    def __init__(self,name):

        self.name = name #The name
        print("this is the name")
        print(self.name)
    
        self.cash = 1000 #The Cash Amount
        
        self.cards = {} #the card information
        self.cardGraphs = []

        self.roundRaise = 0 #roundRaise keeps track of how much a player has raised
        self.actionList = ["place holder"] #actionList keeps track of all the actions a player makes in a round

        self.value = 0 #the value assigned to the player at the end of a hand


#------------------------------------------------------------------------------GENERATE CARD / CLEAR----------------------------------------------------------------------
#Description: Creates functions necessary for generating cards for realtime usage, and clearing cards after a game is done


    def generateCard(self,cardNum): #function that generates a card based off of random values and choosing from a list
        value = ['Ace','2','3','4','5','6','7','8','9','10','Jack','Queen','King']
        pattern = ['Diamonds','Clubs','Hearts','Spades']
        self.card = []
        cardInt = randint(0,12)
        self.cardValue = value[cardInt]
        self.cardPattern = pattern[randint(0,3)]
        self.card.append(self.cardValue)
        self.card.append(self.cardPattern)
        self.card.append(cardInt + 1)
        self.cards[str(cardNum)] = self.card #appends that value to self.cards dictionary

        self.cardGraphs.append(self.cardValue + "_of_" + self.cardPattern.lower() + ".gif")

    def clearCard(self): #Clear the cards
        self.cards = {}
        self.cardGraphs = []

    def removeCash(self,amount): #Removes cash amount from player
        self.cash = int(self.cash - amount)

    def addedFromPot(self,fromPot): #Calls in the pot from the game to be added to the player
        print("$",fromPot,"from the pot will be added to the winning player's hand")
        self.cash = int(self.cash) + fromPot
    

#-------------------------------------------------------------------------------------ACTIONS-----------------------------------------------------------------------------
#Description: Here is where all the players' possible actions within the game are created   

    def fold(self): #Removes a player from being involved in the rest of the hand
        self.actionList.append("FOLD")
        gameStart.playersActions.append("FOLD")
    
    def raiseAmount(self):# Adds an amount of money to the game pot
        #While it doesnt get what i ask, keep running
        try:
            totalCash = int(self.cash) + 1
            while totalCash > int(self.cash): #Checks if you have enough money to raise
                try:
                    totalCash = int(input("How much money would you like to raise?:  "))
                except:
                    print("please reenter amount")
                    raiseAmount(self)
            if totalCash > int(self.cash):  #If not, you get this message
                print("Invalid amount, please try again")
                raiseAmount(self)
        
            else: #If you do have enough money, the raise proceeds
                self.removeCash(totalCash)
                gameStart.addToPot(totalCash)
                gameStart.assignRaise(totalCash)
                self.roundRaise = int(self.roundRaise) + int(totalCash)
                self.actionList.append("RAISE")
                gameStart.playersActions.append("RAISE")
        except: #Error catching
            print("Invalid input")
            print()
            print()
            raiseAmount(self)
                
    def call(self):#Calls the amount raised in the pot
        if int(self.cash) < int(gameStart.amountRaised): #Checks if the player has enough cash to call, if they don't, they put in all of their money, or go "All In"
            gameStart.addToPot(int(self.cash))
            self.removeCash(int(self.cash))
            self.actionList.append("ALLIN")
            gameStart.playersActions.append("ALLIN")
        else: #If they do have enough money, it puts in the raised amount of money inside the pot
            gameStart.addToPot(int(gameStart.amountRaised))
            self.removeCash(int(gameStart.amountRaised))
            self.actionList.append("CALL")
            gameStart.playersActions.append("CALL")
              
    def check(self):#Pass to the next player (no bets, no fold, still in game)
        self.actionList.append("CHECK")
        gameStart.playersActions.append("CHECK")
        pass

#----------------------------------------------------------------------------------TABLE CARD CLASS-----------------------------------------------------------------------
#Description: Handles the creation and removal of the tables on the card (visible to everyone)
       
class TableCards: #Create the table cards (Should be Five each hand, and should be very similar to generateCard)

    def __init__(self,roundNum):
        self.roundNum = roundNum
        self.cards = {}
        self.cardGraphs = []
        
        
    def generateTableCard(self, cardNum): #Generated and appended exactly the same as in the player class
        value = ['Ace','2','3','4','5','6','7','8','9','10','Jack','Queen','King']
        pattern = ['Diamonds','Clubs','Hearts','Spades']

        self.card = []
        cardInt = randint(0,12)
        self.cardValue = value[cardInt]
        self.cardPattern = pattern[randint(0,3)]
        self.card.append(self.cardValue)
        self.card.append(self.cardPattern)
        self.card.append(cardInt + 1)
        self.cards[str(cardNum)] = self.card

        self.cardGraphs.append(self.cardValue + "_of_" + self.cardPattern.lower() + ".gif")

    def clearCard(self): #Clears the cards
        self.cards = {}
        self.cardGraphs = []


#-------------------------------------------------------------------------------GAME CLASS / LOGIC--------------------------------------------------------------------------

class Game: #Game initialization happens here

    def __init__(self,identifier):
        self.identifier = identifier
        self.amountRaised = 0 #the amount that is being raised in a given round

        self.cardsOnTable = [] #the cards on the table 

        self.playersCards = {} #all of the players cards
        self.playersInGame = [] #list of players in game
        self.playersInRound = [] #list of players in round
        self.pot = 0 #total cash amount in the pot
        self.playersActions = ["place holder"] #

    def addToPot(self,amount): #Adds an amount of money to the pot
        self.pot = int(self.pot) + amount

    def clearPot(self): # Clears the entire pot
        self.pot = 0

    def removeFromRound(self,name): #Removes a player from a round by assigning them a number in their place of the list, which then get skipped over
        for player in self.playersInRound:
            if str(player.name) == name:
                player = randint(1,1000)
        
    def clearRaise(self): #Clears the amount raised attribute
        self.amountRaised = 0


    def assignRaise(self,amount): #assigns a raised value to self.amountRaised
        self.amountRaised = int(self.amountRaised) + amount

    def clearCards(): #clears all the cards from the list
        self.cardsOnTable = []


#------------------------------------------------------------------------HIERARCHY-------------------------------------------------------------
#Description: Checks for each player if they fulfill the requirements of having a hand. If they do, the value returned is true, if not, then the value is
#false. Each definition has their own set of rules and standards, which is why some of them check differently.

    def checkIfRoyalFlush(player): #Checks if a player has a royal flush
        pContain = [player]
        valueList = []
        suitList = []
        for player in pContain: #Appends card values to valueList to be iterated through and checked if it meets certain requirements
            valueList.append(player.cards["1"][2])
            valueList.append(player.cards["2"][2])
            valueList.append(self.cardsOnTable[0]["1"][2])
            valueList.append(self.cardsOnTable[0]["2"][2])
            valueList.append(self.cardsOnTable[0]["3"][2])
            valueList.append(self.cardsOnTable[0]["4"][2])
            valueList.append(self.cardsOnTable[0]["5"][2])

            suitList.append(player.cards["1"][1]) #Same process for suitValues
            suitList.append(player.cards["2"][1])
            suitList.append(self.cardsOnTable[0]["1"][1])
            suitList.append(self.cardsOnTable[0]["2"][1])
            suitList.append(self.cardsOnTable[0]["3"][1])
            suitList.append(self.cardsOnTable[0]["4"][1])
            suitList.append(self.cardsOnTable[0]["5"][1])

            valueList = sorted(valueList)
            del valueList[0] #Deletes the last two values since for Royal Flush, we only care about 5 very specific cards
            del valueList[1]
            
            if valueList == [9,10,11,12,13] and suitList.count("Spades") == 5 or suitList.count("Diamonds") == 5 or suitList.count("Clubs") == 5 or suitList.count("Hearts") == 5:
                return True #If Royal Flush requirements are met, returns True
            else: #If not, the lists are cleared and False is returned
                valueList = []
                valueList = []
                return False

            
        #This process occurs for each and every function with mild tweaking

    def checkIfStraightFlush(player): #Checks if a player has a straight flush
        pContain = [player]
        valueList = []
        suitList = []
        for player in pContain:
            valueList.append(player.cards["1"][2])
            valueList.append(player.cards["2"][2])
            valueList.append(self.cardsOnTable[0]["1"][2])
            valueList.append(self.cardsOnTable[0]["2"][2])
            valueList.append(self.cardsOnTable[0]["3"][2])
            valueList.append(self.cardsOnTable[0]["4"][2])
            valueList.append(self.cardsOnTable[0]["5"][2])

            suitList.append(player.cards["1"][1])
            suitList.append(player.cards["2"][1])
            suitList.append(self.cardsOnTable[0]["1"][1])
            suitList.append(self.cardsOnTable[0]["2"][1])
            suitList.append(self.cardsOnTable[0]["3"][1])
            suitList.append(self.cardsOnTable[0]["4"][1])
            suitList.append(self.cardsOnTable[0]["5"][1])

            valueList = sorted(valueList)

            for values in valueList:
                if valueList[values + 1] != values + 1:
                    valueList = []
                    suitList = []
                    return False
                else:
                    if suitList.count("Spades") == 5 or suitList.count("Hearts") == 5 or suitList.count("Clubs") == 5 or suitList.count("Diamonds") == 5:
                        return True
                    else:
                        return False
            
        

    def checkIf4ofaKind(player): #Checks if a player has a 4 of a kind
        pContain = [player]
        valueList = []
        suitList = []
        tfList = []
        for player in pContain:
            valueList.append(player.cards["1"][2])
            valueList.append(player.cards["2"][2])
            valueList.append(self.cardsOnTable[0]["1"][2])
            valueList.append(self.cardsOnTable[0]["2"][2])
            valueList.append(self.cardsOnTable[0]["3"][2])
            valueList.append(self.cardsOnTable[0]["4"][2])
            valueList.append(self.cardsOnTable[0]["5"][2])

            suitList.append(player.cards["1"][1])
            suitList.append(player.cards["2"][1])
            suitList.append(self.cardsOnTable[0]["1"][1])
            suitList.append(self.cardsOnTable[0]["2"][1])
            suitList.append(self.cardsOnTable[0]["3"][1])
            suitList.append(self.cardsOnTable[0]["4"][1])
            suitList.append(self.cardsOnTable[0]["5"][1])

            valueList = sorted(valueList)

            for i in range(1,14):
                if valueList.count(i) == 4:
                    tfList.append(True)
                else:
                    tfList.append(False)
            if tfList.count(True) == 1:
                return True
            else:
                valueList = []
                suitList = []
                tfList = []
                return False


    def checkIfFullHouse(player): #Checks if a player has a full house
        pContain = [player]
        valueList = []
        suitList = []
        tfList = []
        for player in pContain:
            valueList.append(player.cards["1"][2])
            valueList.append(player.cards["2"][2])
            valueList.append(self.cardsOnTable[0]["1"][2])
            valueList.append(self.cardsOnTable[0]["2"][2])
            valueList.append(self.cardsOnTable[0]["3"][2])
            valueList.append(self.cardsOnTable[0]["4"][2])
            valueList.append(self.cardsOnTable[0]["5"][2])

            suitList.append(player.cards["1"][1])
            suitList.append(player.cards["2"][1])
            suitList.append(self.cardsOnTable[0]["1"][1])
            suitList.append(self.cardsOnTable[0]["2"][1])
            suitList.append(self.cardsOnTable[0]["3"][1])
            suitList.append(self.cardsOnTable[0]["4"][1])
            suitList.append(self.cardsOnTable[0]["5"][1])

            valueList = sorted(valueList)

            for i in valueList:
                if valueList.count(i) == 2:
                    tfList.append(True)
                elif valueList.count(i) == 3:
                    tfList.append(True)
                else:
                    tfList.append(False)
            if tfList.count(True) == 2:
                return True
            else:
                valueList = []
                suitList = []
                tfList = []
                return False

            
    def checkIfFlush(player): #Checks if a player has a flush
        pContain = [player]
        suitList = []
        for player in pContain:
            suitList.append(player.cards["1"][1])
            suitList.append(player.cards["2"][1])
            suitList.append(self.cardsOnTable[0]["1"][1])
            suitList.append(self.cardsOnTable[0]["2"][1])
            suitList.append(self.cardsOnTable[0]["3"][1])
            suitList.append(self.cardsOnTable[0]["4"][1])
            suitList.append(self.cardsOnTable[0]["5"][1])

            if suitList.count("Spades") == 5 or suitList.count("Hearts") == 5 or suitList.count("Clubs") == 5 or suitList.count("Diamonds") == 5:
                return True
            else:
                suitList = []
                return False
                
        

    def checkIfStraight(player): #Checks if a player has straight
        pContain = [player]
        valueList = []
        suitList = []
        for player in pContain:
            valueList.append(player.cards["1"][2])
            valueList.append(player.cards["2"][2])
            valueList.append(self.cardsOnTable[0]["1"][2])
            valueList.append(self.cardsOnTable[0]["2"][2])
            valueList.append(self.cardsOnTable[0]["3"][2])
            valueList.append(self.cardsOnTable[0]["4"][2])
            valueList.append(self.cardsOnTable[0]["5"][2])

            suitList.append(player.cards["1"][1])
            suitList.append(player.cards["2"][1])
            suitList.append(self.cardsOnTable[0]["1"][1])
            suitList.append(self.cardsOnTable[0]["2"][1])
            suitList.append(self.cardsOnTable[0]["3"][1])
            suitList.append(self.cardsOnTable[0]["4"][1])
            suitList.append(self.cardsOnTable[0]["5"][1])

            valueList = sorted(valueList)

            for values in valueList:
                if valueList[values + 1] != values + 1:
                    valueList = []
                    suitList = []
                    return False
                else:
                    return True

    def checkIf3ofaKind(player): #Checks if a player has a 3 of a kind
        pContain = [player]
        valueList = []
        suitList = []
        tfList = []
        for player in pContain:
            valueList.append(player.cards["1"][2])
            valueList.append(player.cards["2"][2])
            valueList.append(self.cardsOnTable[0]["1"][2])
            valueList.append(self.cardsOnTable[0]["2"][2])
            valueList.append(self.cardsOnTable[0]["3"][2])
            valueList.append(self.cardsOnTable[0]["4"][2])
            valueList.append(self.cardsOnTable[0]["5"][2])

            suitList.append(player.cards["1"][1])
            suitList.append(player.cards["2"][1])
            suitList.append(self.cardsOnTable[0]["1"][1])
            suitList.append(self.cardsOnTable[0]["2"][1])
            suitList.append(self.cardsOnTable[0]["3"][1])
            suitList.append(self.cardsOnTable[0]["4"][1])
            suitList.append(self.cardsOnTable[0]["5"][1])

            valueList = sorted(valueList)

            for i in range(1,14):
                if valueList.count(i) == 3:
                    tfList.append(True)
                else:
                    tfList.append(False)
            if tfList.count(True) == 1:
                return True
            else:
                valueList = []
                suitList = []
                tfList = []
                return False

    def checkIf2Pair(player): #Checks if a player has a 2 pair
        pContain = [player]
        valueList = []
        suitList = []
        tfList = []
        for player in self.playersInRound:
            valueList.append(player.cards["1"][2])
            valueList.append(player.cards["2"][2])
            valueList.append(self.cardsOnTable[0]["1"][2])
            valueList.append(self.cardsOnTable[0]["2"][2])
            valueList.append(self.cardsOnTable[0]["3"][2])
            valueList.append(self.cardsOnTable[0]["4"][2])
            valueList.append(self.cardsOnTable[0]["5"][2])

            suitList.append(player.cards["1"][1])
            suitList.append(player.cards["2"][1])
            suitList.append(self.cardsOnTable[0]["1"][1])
            suitList.append(self.cardsOnTable[0]["2"][1])
            suitList.append(self.cardsOnTable[0]["3"][1])
            suitList.append(self.cardsOnTable[0]["4"][1])
            suitList.append(self.cardsOnTable[0]["5"][1])

            valueList = sorted(valueList)

            for i in range(1,14):
                if valueList.count(i) == 2:
                    tfList.append(True)
                else:
                    tfList.append(False)
            if tfList.count(True) == 2:
                return True
            else:
                valueList = []
                suitList = []
                tfList = []
                return False

    def checkIf1Pair(player): #Checks if a player has a 1 pair
        pContain = [player]
        valueList = []
        suitList = []
        tfList = []
        for player in self.playersInRound:
            valueList.append(player.cards["1"][2])
            valueList.append(player.cards["2"][2])
            valueList.append(self.cardsOnTable[0]["1"][2])
            valueList.append(self.cardsOnTable[0]["2"][2])
            valueList.append(self.cardsOnTable[0]["3"][2])
            valueList.append(self.cardsOnTable[0]["4"][2])
            valueList.append(self.cardsOnTable[0]["5"][2])

            suitList.append(player.cards["1"][1])
            suitList.append(player.cards["2"][1])
            suitList.append(self.cardsOnTable[0]["1"][1])
            suitList.append(self.cardsOnTable[0]["2"][1])
            suitList.append(self.cardsOnTable[0]["3"][1])
            suitList.append(self.cardsOnTable[0]["4"][1])
            suitList.append(self.cardsOnTable[0]["5"][1])

            valueList = sorted(valueList)

            for i in range(1,14):
                if valueList.count(i) == 2:
                    tfList.append(True)
                else:
                    tfList.append(False)
            if tfList.count(True) == 1:
                return True
            else:
                valueList = []
                suitList = []
                tfList = []
                return False

    def checkIfHighCard(): #By default, this returns True, since having a high card just means having a card to put down. Almost never wins
        #if you reach this point, you basically lost
        return True

    def hierarchy(player): #Calls all the functions together in one function, returns a value from 1-10 if conditions are met (10 being the best, 1 the worst)
        if checkIfRoyalFlush(player):
            return 10
        elif checkIfStraightFlush(player):
            return 9
        elif checkIf4ofaKind(player):
            return 8
        elif checkIfFullHouse(player):
            return 7
        elif checkIfFlush(player):
            return 6
        elif checkIfStraight(player):
            return 5
        elif checkIf3ofaKind(player):
            return 4
        elif checkIf2ofaKind(player):
            return 3
        elif checkIf1Pair(player):
            return 2
        elif checkIfHighCard(player):
            return 1

#-------------------------------------------------------------------------------MENUS---------------------------------------------------------------------
#Description: Functions for start menu, player amount, and player name input.

    def startMenu(self): #Creates the start menu
        win = GraphWin("Poker Start Menu",400,400)
        backgroundImage1 = Image(Point(50,250),"poker screen image 1.gif")
        backgroundImage1.draw(win)
        title = Text(Point(200,150),"Welcome to Poker")
        title.setSize(20)
        title.draw(win)
        startButton = Rectangle(Point(50,200),Point(350,350))
        startButton.setFill("white")
        startButton.draw(win)
        startButtonMessage = Text(Point(200,275),"START")
        startButtonMessage.setSize(25)
        startButtonMessage.draw(win)
        startButtonClick = win.getMouse()
        #fix this and remake for all player screens
        needToChange = 3
        while(needToChange == 3): #Will not execute the next screen till the button within those borders is pressed
            startButtonClick = win.getMouse()
            if startButtonClick.getX() > 50 and startButtonClick.getX() < 350 and startButtonClick.getY() > 200 and startButtonClick.getY() < 350:
                needToChange = 10
                win.close()
                self.howManyPlayerScreen()
                continue
            else:
                #startButtonClick.getX() < 50 > 350 or startButtonClick.getY() < 50 > 350:
                needToChange = 3
                
            
    def howManyPlayerScreen(self): #Creates the player amount screen
        win = GraphWin("How Many Player Screen",400,300)
        backgroundImage2 = Image(Point(200,150),"poker screen image 2.gif")
        backgroundImage2.draw(win)
        numberOfPlayers = Text(Point(200,75),"There can only be 2-8 players")
        howManyPlayersOne = Text(Point(200,100),"How Many Players will there be?")
        howManyPlayersOne.setTextColor("black")
        howManyPlayersFile = open("how many players.txt","w")
        howManyPlayersTwo = Entry(Point(200,150),1)
        howManyPlayersGetText = howManyPlayersTwo.getText()
        howManyPlayersFile.write(howManyPlayersGetText)
        howManyPlayersFile.close()
        howManyPlayersOne.draw(win)
        howManyPlayersTwo.draw(win)
        doneButtonPartOne = Rectangle(Point(175,200),Point(225,225))
        doneButtonPartOne.setFill("white")
        doneButtonPartTwo = Text(Point(200,212.5),"DONE")
        doneButtonPartOne.draw(win)
        doneButtonPartTwo.draw(win)
        doneButtonClick = win.getMouse()
        howManyPlayers = howManyPlayersTwo.getText()
        needToChange = 0
        while(needToChange == 0): #Same as before, this screen will not execute the next screen until the button is pressed
            if doneButtonClick.getX() >175 < 225 and doneButtonClick.getY() >200 < 225:
                if howManyPlayers == '2' or howManyPlayers == '3' or howManyPlayers == '4' or howManyPlayers == '5' or howManyPlayers == '6' or howManyPlayers =='7' or howManyPlayers =='8':
                    win.close()
                    needToChange = 3
                    self.playerNameScreen(howManyPlayers)
                else: #If the input isn't correct, the menu shows up again
                    needToChange = 0
                    backgroundImage2 = Image(Point(200,150),"poker screen image 2.gif")
                    backgroundImage2.draw(win)
                    numberOfPlayers = Text(Point(200,75),"There can only be 2-8 players")
                    howManyPlayersOne = Text(Point(200,100),"How Many Players will there be?")
                    howManyPlayersOne.setTextColor("black")
                    howManyPlayersFile = open("how many players.txt","w")
                    howManyPlayersTwo = Entry(Point(200,150),1)
                    howManyPlayersGetText = howManyPlayersTwo.getText()
                    howManyPlayersFile.write(howManyPlayersGetText)
                    howManyPlayersFile.close()
                    howManyPlayersOne.draw(win)
                    howManyPlayersTwo.draw(win)
                    doneButtonPartOne = Rectangle(Point(175,200),Point(225,225))
                    doneButtonPartOne.setFill("white")
                    doneButtonPartTwo = Text(Point(200,212.5),"DONE")
                    doneButtonPartOne.draw(win)
                    doneButtonPartTwo.draw(win)
                    doneButtonClick = win.getMouse()
                    howManyPlayers = howManyPlayersTwo.getText()
            else: #If the input isn't correct, the menu shows up again
                needToChange = 0
                backgroundImage2 = Image(Point(200,150),"poker screen image 2.gif")
                backgroundImage2.draw(win)
                numberOfPlayers = Text(Point(200,75),"There can only be 2-8 players")
                howManyPlayersOne = Text(Point(200,100),"How Many Players will there be?")
                howManyPlayersOne.setTextColor("black")
                howManyPlayersFile = open("how many players.txt","w")
                howManyPlayersTwo = Entry(Point(200,150),1)
                howManyPlayersGetText = howManyPlayersTwo.getText()
                howManyPlayersFile.write(howManyPlayersGetText)
                howManyPlayersFile.close()
                howManyPlayersOne.draw(win)
                howManyPlayersTwo.draw(win)
                doneButtonPartOne = Rectangle(Point(175,200),Point(225,225))
                doneButtonPartOne.setFill("white")
                doneButtonPartTwo = Text(Point(200,212.5),"DONE")
                doneButtonPartOne.draw(win)
                doneButtonPartTwo.draw(win)
                doneButtonClick = win.getMouse()
                howManyPlayers = howManyPlayersTwo.getText()

    def playerNameScreen(self,howManyPlayers): # Asks for the name of each player
        win = GraphWin("Player Name Screen",600,600)
        backgroundImage3 = Image(Point(400,400),"poker screen image 3.gif")
        backgroundImage3.draw(win)
        playerNameFile = open("player names.txt","w")
        for i in range(int(howManyPlayers)):
            doneClickMessage = Text(Point(400,50),'Click screen when done typing in')
            doneClickMessage.draw(win)
            question = "What is the name of player number",i+1,"?"
            askingPlayerName = Text(Point(150,100 + i*20),question)
            askingPlayerName.draw(win)
            inputPlayerName = Entry(Point(350,100 + i*20),10)
            inputPlayerName.draw(win)
            win.getMouse()
            playerName = str(inputPlayerName.getText())
            doneButtonClick = win.getMouse()
            player = Player(playerName)
            self.playersInGame.append(player)
            self.playersInRound.append(player)
            playerNameFile.write(playerName + ",")
        playerNameFile.close() #The names are then appended to a list, the window is closed, and the official poker game begins
        win.close()
        self.poker()#this function will be called to play the game, the players variable will be used
            
#------------------------------------------------------------POKER FUNCTION / GAME FLOW------------------------------------------------------
#Description: This is where the main events of the poker game occur. Decisions can be made here by the players based on their previous choices.

    def poker(self):
    #in the shell it will first say, start game
        print("Poker Game Start...")
    #put everything in while loop (have everything run until one player has all the chips 
    #use loop to loop through every player in the playerInRound list from the playNameScreen
        tableCards = TableCards(1)
        winner = None
        bestHand = None
        while winner == None:
            print("the Pre-Flop starts now")
            print()
            handDone = self.turnsNoCards(bestHand) #pass winner into the turn methods so to decided the winner if all players fold but one player, how do i stop this method and
            #get out of it to decided the winner of the hand
            if handDone:
                continue
            #show the first three cards
            print("the Flop starts now")
            print()
            print("these are the first 3 cards on the table")
            #change to separate functions for each round
            tableCards.generateTableCard(1)
            tableCards.generateTableCard(2)
            tableCards.generateTableCard(3)
                
            card1Name = tableCards.cardGraphs[0]
            card2Name = tableCards.cardGraphs[1]
            card3Name = tableCards.cardGraphs[2]

            win = GraphWin("TableCards",1000,1000)
            TableCard1 = Image(Point(300,400),card1Name)
            TableCard1.draw(win)
            TableCard2 = Image(Point(600,400),card2Name)
            TableCard2.draw(win)
            TableCard3 = Image(Point(900,400),card3Name)
            TableCard3.draw(win)
                
            #use loop to loop through every player in the playerList list from the playNameScreen
            handDone = self.turnsWithCards(bestHand)
            if handDone:
                TableCard1.undraw()
                TableCard2.undraw()
                TableCard3.undraw()
                tableCards.clearCards()
                continue
            print("the Turn starts now")
            print()
            print("This is the 4th card on the table")
            tableCards.generateTableCard(4)

            card4Name = tableCards.cardGraphs[3]
            TableCard4 = Image(Point(300,700),card4Name)
            TableCard4.draw(win)

            #use loop to loop through every player in the playerList list from the playNameScreen
            handDone = self.turnsWithCards(bestHand)
            if handDone:
                TableCard1.undraw()
                TableCard2.undraw()
                TableCard3.undraw()
                TableCard4.undraw()
                tableCards.clearCards()
                continue
            #show 5th card
            print("The River starts now")
            print()
            print("This is the 5th and last card on the table")
            tableCards.generateTableCard(5)
            self.cardsOnTable.append(tableCards.cards)
            card5Name = tableCards.cardGraphs[4]
            TableCard5 = Image(Point(500,700),card5Name)
            TableCard5.draw(win)

            handDone = self.turnsWithCards(bestHand)
            if handDone:
                TableCard1.undraw()
                TableCard2.undraw()
                TableCard3.undraw()
                TableCard4.undraw()
                TableCard4.undraw()
                tableCards.clearCards()
                continue
            #assigns each player a number based on what their cards are
            for player in self.playersInRound:
                player.value = hierarchy(player)
                    
            playersWithBestHand = self.whoHasBestHand(self.playersInRound)
            #decided who has the best hand
            #print out how many chips will be added from the pot to the winning players chips, if statement to pas on if players
            for player in self.playersInRound:
                if player.actionList[-1] == "FOLD":
                    pass
                elif player.acrionList[-1] != "FOLD":
                    if bestHand.value < player.value:
                        bestHand = dude
                
            #adds pot to player with best hand
            print("The player with the best hand is", bestHand.name)
            bestHand.addedFromPot(int(self.pot))

            #loop to see if player has all the chips or not and decided winer of game if a player does
            
            #reassigns each players actionList to an empty list and removes all their cards
            for player in self.playersInRound:
                player.actionList = []
                player.fold()
                #undraws table cards
            TableCard1.undraw()
            TableCard2.undraw()
            TableCard3.undraw()
            TableCard4.undraw()
            TableCard5.undraw()
                
            #clears table cards
            tableCards.clearCard()
                
            #puts back in the removed players of the 
            self.playersInRound = self.playersInGame
                
            if (winner):
                break
            
                
                #use if state to decided which player drops out by if player chips = 0 or is unable to raise, get rid of player from list
                for pos, player in enumerate(self.playersInGame):
                    if player.cash == 0:
                        #remove from playerList
                        theList.pop(pos)
                else:
                    pass
        #if there is more than 1 player able to make a play, recall this function to start over/ put this all into a loop and this loop stops when a player
                  #has all the chips or only one player is able to make a move
        #use if statement to decided game winning player by if all chips belong to certain player that player wins
            if len(self.playersInRound) == 1:
                print("the winner of this game of poker is",self.playersInRound[0].name,)
                playAgain = input("would you like to play again? type yes or no").rstrip().lstrip()
                if playAgain == "yes":
                    startMenu()
                elif playAgain == "no":
                    exit()
        playAgain = eval(input("what would you like to do now? (play again or close"))
        if playAgain.upper().rstrip().lstrip() == "CLOSE":
            exit()
        elif playAgain.upper().rstrip().lstrip() == "PLAY AGAIN":
            self.startMenu()
            
            for player in self.playersInRound:
                if player.cash == (len(self.playersInGame) * 1000):
                    winner = player
                    print("The winner of this game of poker is", winner.name)
                    winnerFile = open("Winner of Poker","w")
                    winnerFile.write(winner.name + datetime.datetime.now())
                    break
                else:
                    pass
        
        #winnerNameFile = open("winner","w")
        #winnerNameFile.write(winner)



#----------------------------------------------------------------MISCELLANEOUS---------------------------------------------------------------
#Description: Functions that contribute to the Game flow but called outside are stored here. 

    def whoHasBestHand(self, playerList): #Checks who has the best hand at the end of a hand
        # Input: list of players
        # Output: list of best players

        #decided who has the best hand
        #print out how many chips will be added from the pot to the winning players chips, if statement to pas on if players
        bestSoFar = [playerList[0]] #The list is constantly updated with whoever has the highest value
        for player in playerList:
            if player.actionList[-1] == "FOLD": #If the player's last action was fold, he is passed in the list
                pass
            elif player.actionList[-1] != "FOLD": #If the player's last action was not fold, that player becomes assigned to bestSoFar
                if bestSoFar[-1].value < player.value:
                    bestSoFar = [player]
                elif bestSoFar[-1].value == player.value:
                    bestSoFar.append(player)

        return bestSoFar #returns the best player / hand


    def checkIfPlayersFold(self,bestHand): #Checks if the players folded based on the parameter bestHand
        if bestHand == None: #if there is no bestHand, the if statement passes
                pass
        else: #if there is a bestHand, all the action lists are cleared, that player then folds, and the player with the bestHand gets the cash
            for player in self.playersInRound:
                player.actionList = []
                player.fold()
            bestHand.cash = int(bestHand.cash) + int(self.pot)
            self.pot = 0
            bestHand = None    

    def clearActions(self): #clears the action list
        self.playersActions = []

    def clearPlayersWhoFolded(self): #clears the folded list
        self.playersWhoFolded = []
                    

#------------------------------------------------------------------TURNS WITH / WITHOUT CARDS------------------------------------------------------------------
#Description: Turns with cards executes after the first three cards are drawn, Turns without cards executes before the first three are drawn
                #This is because turns without cards creates the players cards for the first time, whereas turns without cards is just a "normal" round

    def turnsNoCards(self,bestHand): #Creates the pre-flop turn
        playerList = self.playersInRound
        win = GraphWin("player cards",1000,1000)
        #fix here where to create the hands for all the players and how to draw each players individuial hands when its their turn
        for dude in playerList:
            if self.playersActions.count("FOLD") == (len(playerList)-1):
                print(dude.name, " just won the hand")
                #if all players fold and the last player has not bet, they win the hand-----------------------------------------------------------------------
                bestHand = dude
                #get out of this method and go to poker function
                self.checkIfPlayersFold(bestHand)
                self.clearActions()
                win.close()
                return True
            else:
                #if all players fold and the last player has not bet, they win the hand-----------------------------------------------------------------------
                print("It is",dude.name,"'s turn") ### ASK WHY IT DOESNT WORK
                print("You currently have $",dude.cash," in your account",sep = "")
                dude.generateCard(1)
                dude.generateCard(2)
                Image(Point(250,500),dude.cardGraphs[0]).draw(win)
                Image(Point(750,500),dude.cardGraphs[1]).draw(win)
                #user input what they want to do
                action = "" 
                while action.upper() != "FOLD" or action.upper() != "RAISE" or action.upper() != "CHECK" or action.upper() != "CALL":
                    print("RULES:")
                    print("You can only call when the player before you has raised,")
                    print("Once a person has already raised you cannot check,")
                    print("You can only check if no other players have bet anything.")
                    action = input("what would you like to do? enter fold, raise, call, or check: ")
                    #based on what they choose to do call the function that allows them to do the action
                    if action.upper().rstrip().lstrip() == "FOLD":
                        Image(Point(250,500),dude.cardGraphs[0]).undraw()
                        Image(Point(750,500),dude.cardGraphs[1]).undraw()
                        dude.fold()
                        break 
                    elif action.upper().rstrip().strip() == "RAISE":
                        dude.raiseAmount()
                        Image(Point(250,500),dude.cardGraphs[0]).undraw()
                        Image(Point(750,500),dude.cardGraphs[1]).undraw()
                        break
                    elif action.upper().rstrip().lstrip() == "CHECK":
                        if self.playersActions.count("RAISE") >= 1:
                            print("The previous player(s) have raised, you cannot check")
                            action = ""
                        else:
                            dude.check()
                            Image(Point(250,500),dude.cardGraphs[0]).undraw()
                            Image(Point(750,500),dude.cardGraphs[1]).undraw()
                            break
                    elif action.upper().rstrip().lstrip() == "CALL":
                        if self.amountRaised == 0:
                            print("Theres is nothing in the pot to call on")
                            action = ""
                        else:
                            dude.call()
                            Image(Point(250,500),dude.cardGraphs[0]).undraw()
                            Image(Point(750,500),dude.cardGraphs[1]).undraw()
                            break
        #here check actionsList to see if the number of times FOLD is in it == len(playerList)-1, similar to line 817
                    #print()
                    if self.playersActions.count("FOLD") == (len(playerList)-1) :
                        #print(self.playersActions.count("FOLD")
                        for dude in playerList:
                            print(dude.actionList.count("FOLD"))
                            if dude.actionList.count("FOLD") > 0:
                                print()
                            elif dude.actionList.count("FOLD") == 0:
                                print(dude.name, " just won the hand")
                                #if all players fold and the last player has not bet, they win the hand-----------------------------------------------------------------------
                                bestHand = dude
                                #get out of this method and go to poker function
                                self.checkIfPlayersFold(bestHand)
                                self.clearActions()
                                win.close()
                                return True
                            else:
                                print("something went wrong")
                    else:
                        print("no choice entered")
                        action = ""
                print()
        #if the last element within playersActions (playerActions is in order a list of all the players actions)
        #players who have folded before will be skipped
        while self.playersActions[-1] == "RAISE":
            #if all players fold and one player doesnt, that player wins the hand
            for dude in playerList:
                if dude.actionList[-1] == "FOLD" or dude.actionList[-1] == "ALLIN":
                    pass
                else:
                    if self.playersActions.count("FOLD") == (len(playerList)-1):
                        print(dude.name,"just won the hand")
                        bestHand = dude
                        self.checkIfPlayersFold(bestHand)
                        win.close()
                        self.clearActions()
                        return True
                    else:
                        print("It is",dude.name,"'s turn") ### ASK WHY IT DOESNT WORK
                        print("You currently have $",dude.cash," in your account",sep = "")
                        Image(Point(250,500),dude.cardGraphs[0]).draw(win)
                        Image(Point(750,500),dude.cardGraphs[1]).draw(win)
                        action = ""
                        while action.upper() != "FOLD" or action.upper() != "RAISE" or action.upper() != "CALL":
                            print("RULES:")
                            print("you can only call when the player before you has raised")
                            print("Once a person has already raised you cannot check")
                            print("you can only check if no other players have bet anything")
                            action = input("what would you like to do? enter fold, call, check, or raise:")
                            if action.upper().rstrip().lstrip() == "RAISE":                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
                                dude.raiseAmount()
                                Image(Point(250,500),dude.cardGraphs[0]).undraw()
                                Image(Point(750,500),dude.cardGraphs[1]).undraw()
                                break
                            elif action.upper().rstrip().lstrip() == "FOLD": 
                                Image(Point(250,500),dude.cardGraphs[0]).undraw()
                                Image(Point(750,500),dude.cardGraphs[1]).undraw()
                                dude.fold()
                                break
                            elif action.upper().rstrip().lstrip() == "CALL":
                                if self.amountRaised == 0:
                                    print("Theres is nothing in the pot to call on")
                                    action = ""
                                else:
                                    dude.call()
                                    Image(Point(250,500),dude.cardGraphs[0]).undraw()
                                    Image(Point(750,500),dude.cardGraphs[1]).undraw()
                                    break
                            elif action.upper().rstrip().lstrip() == "CHECK":
                                if self.playersActions.count("RAISE") >= 1:
                                    print("The previous player has raise, you cannot check")
                                    action = ""
                                else:
                                    dude.check()
                                    Image(Point(250,500),dude.cardGraphs[0]).undraw()
                                    Image(Point(750,500),dude.cardGraphs[1]).undraw()
                                    break
                                
                            else:
                                print("no choice entered")
                                action = ""
                        
        #here check actionsList to see if the number of times FOLD is in it == len(playerList)-1, similar to line 817
                            if self.playersActions.count("FOLD") == (len(playerList)-1):
                                for dude in playerList:
                                        if dude.actionList.count("FOLD") > 0:
                                            print()
                                        elif dude.actionList.count("FOLD") == 0:
                                            print(dude.name, " just won the hand")
                                            #if all players fold and the last player has not bet, they win the hand-------------------------
                                            bestHand = dude
                                            #get out of this method and go to poker function
                                            self.checkIfPlayersFold(bestHand)
                                            self.clearActions()
                                            win.close()
                                            return True
                        print()
                        
        self.clearActions()
        win.close()
                
    def turnsWithCards(self,bestHand): #Creates the post flop turn
        cardWin = GraphWin("player cards",1000,1000)
        playerList = self.playersInRound
        for dude in playerList:
            #if all playes besides one decided to fold, that one player wins the hand
            if dude.actionList[-1] == "FOLD" or dude.actionList[-1] == "ALLIN":
                pass
            elif dude.actionList[-1] != "FOLD":
                if self.playersActions.count("FOLD") == (len(playerList)-1):
                    print(dude.name,"is the winner of the hand")
                    bestHand = dude
                    self.checkIfPlayersFold(bestHand)
                    self.clearActions()
                    cardWin.close()
                    return True
                else:
                    print("It is",dude.name,"'s turn") ### ASK WHY IT DOESNT WORK
                    print("You currently have $",dude.cash," in your account",sep = "")
                    #show the player their hand
                    Image(Point(250,500),dude.cardGraphs[0]).draw(cardWin)
                    Image(Point(750,500),dude.cardGraphs[1]).draw(cardWin)
                    action = ""
                    while action.upper != "FOLD" or action.upper != "RAISE" or action.upper != "CHECK":
                    #user input what they want to do
                        print("RULES:")
                        print("you can only call when the player before you has raised")
                        print("Once a person has already raised you cannot check")
                        print("you can only check if no other players have bet anything")
                        action = input("what action would you like to do? (fold, raise, call, or check): ")
                        #based on what they choose to do call the function that allows them to do the action
                        if action.upper().rstrip().lstrip() == "FOLD":
                            Image(Point(250,500),dude.cardGraphs[0]).undraw()
                            Image(Point(750,500),dude.cardGraphs[1]).undraw()
                            dude.fold()
                            break    
                        elif action.upper().rstrip().lstrip() == "RAISE":
                            dude.raiseAmount()
                            Image(Point(250,500),dude.cardGraphs[0]).undraw()
                            Image(Point(750,500),dude.cardGraphs[1]).undraw()
                            break
                        elif action.upper().rstrip().lstrip() == "CALL":
                            if self.amountRaised == 0:
                                print("Theres is nothing in the pot to call on")
                                action = ""
                            else:
                                dude.call()
                                Image(Point(250,500),dude.cardGraphs[0]).undraw()
                                Image(Point(750,500),dude.cardGraphs[1]).undraw()
                                break
                        elif action.upper().rstrip().lstrip() == "CHECK":
                            if self.playersActions.count("RAISE") >= 1:
                                print("The previous player has raise, you cannot check")
                                action = ""
                            else:
                                dude.check()
                                Image(Point(250,500),dude.cardGraphs[0]).undraw()
                                Image(Point(750,500),dude.cardGraphs[1]).undraw()
                                break
                        else:
                            print("no action entered, please try again")
                            action = ""
        #here check actionsList to see if the number of times FOLD is in it == len(playerList)-1, similar to line 817
                        if self.playersActions.count("FOLD") == (len(playerList)-1):
                            for dude in playerList:
                                if dude.actionList.count("FOLD") > 0:
                                    print()
                                elif dude.actionList.count("FOLD") == 0:
                                    print(dude.name, " just won the hand")
                                    #if all players fold and the last player has not bet, they win the hand------------------------------------
                                    bestHand = dude
                                    #get out of this method and go to poker function
                                    self.checkIfPlayersFold(bestHand)
                                    self.clearActions()
                                    cardWin.close()
                                    return True
                    print()
        while self.playersActions[-1] == "RAISE":
            #if all players fold, the player that didnt fold wins the hand
            for dude in playerList:
                if dude.actionList[-1] == "FOLD" or dude.actionList[-1] == "ALLIN":
                    pass
                else:
                    if self.playersActions.count("FOLD") == (len(playerList)-1):
                        print(dude.name,"is the winner of the hand")
                        bestHand = dude
                        self.checkIfPlayersFold(bestHand)
                        self.clearActions()
                        cardWin.close()
                        return True
                    else:
                        print("It is",dude.name,"'s turn") ### ASK WHY IT DOESNT WORK
                        print("You currently have $",dude.cash," in your account",sep = "")
                        Image(Point(250,500),dude.cardGraphs[0]).draw(cardWin)
                        Image(Point(750,500),dude.cardGraphs[1]).draw(cardWin)
                        action = ""
                        while action.upper() != "FOLD" or action.upper() != "RAISE" or action.upper() != "CALL":
                            print("RULES:")
                            print("you can only call when the player before you has raised")
                            print("Once a person has already raised you cannot check")
                            print("you can only check if no other players have bet anything")
                            action = input("what would you like to do? enter fold, call, check, or raise:").upper().rstrip().lstrip()
                            if action == "RAISE":                                                                                                                                                                                                                                                                                                                                                                                                                                                
                                dude.raiseAmount()
                                Image(Point(250,500),dude.cardGraphs[0]).undraw()
                                Image(Point(750,500),dude.cardGraphs[1]).undraw()
                                break
                            elif action == "FOLD":
                                Image(Point(250,500),dude.cardGraphs[0]).undraw()
                                Image(Point(750,500),dude.cardGraphs[1]).undraw()
                                dude.fold()
                                break
                            elif action.upper().rstrip().lstrip() == "CALL":
                                if self.amountRaised == 0:
                                    print("Theres is nothing in the pot to call on")
                                    action = ""
                                else:
                                    dude.call()
                                    Image(Point(250,500),dude.cardGraphs[0]).undraw()
                                    Image(Point(750,500),dude.cardGraphs[1]).undraw()
                                    break
                            elif action.upper().rstrip().lstrip() == "CHECK":
                                if self.playersActions.count("RAISE") >= 1:
                                    print("The previous player has raise, you cannot check")
                                    action = ""
                                else:
                                    dude.check()
                                    Image(Point(250,500),dude.cardGraphs[0]).undraw()
                                    Image(Point(750,500),dude.cardGraphs[1]).undraw()
                                    break
                            else:
                                print("no choice entered")
                                action = ""
                        #here check actionsList to see if the number of times FOLD is in it == len(playerList)-1, similar to line 817
                            if self.playersActions.count("FOLD") == (len(playerList)-1):
                                for dude in playerList:
                                    if dude.actionList.count("FOLD") > 0:
                                        print()
                                    elif dude.actionList.count("FOLD") == 0:
                                        print(dude.name, " just won the hand")
                                        #if all players fold and the last player has not bet, they win the hand--------------------
                                        bestHand = dude
                                        #get out of this method and go to poker function
                                        self.checkIfPlayersFold(bestHand)
                                        self.clearActions()
                                        cardWin.close()
                                        return True
                        print()
        self.clearActions()
        cardWin.close()
#Global game variable declared for easy access            
gameStart = Game("placehold")
gameStart.startMenu()
