class Pot: #Set pot as own property, add removing and adding CHIPS to pot and out of pot. self.color used for reference in class
    def __init__(self,name):
              self.name = 0
              self.white = 0
              self.blue = 0
              self.green = 0
              self.red = 0
              self.black = 0

              self.pot = [int(self.white),int(self.blue),int(self.green),int(self.red),int(self.black)]
    def addToPot(self,white,blue,green,red,black):
              self.white = self.white + white
              self.blue = self.blue + blue
              self.green = self.green + green
              self.red = self.red + red
              self.black = self.black + black

              self.pot[0] = int(self.white)
              self.pot[1] = int(self.blue)
              self.pot[2] = int(self.green)
              self.pot[3] = int(self.red)
              self.pot[4] = int(self.black)
