the = "james"
vars()[the] = "test"

print(james + "test")
