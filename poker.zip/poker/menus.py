#Create the Player amount screen
    #The Player amount screen / prompt should have a prompt asking the user how many
    #players are playing. The amount should be between 2 and 8. If an invalid number is
    #entered, print a message saying "Invalid number, Try again"
    #There should also be a "Main Menu" button / code that takes you back to the main menu.
from graphics import *

def playerNameScreen(howManyPlayers):
    win = GraphWin("Player Name Screen",600,600)
    win.setBackground("green")
    playerNameFile = open("player names.txt","w")
    for i in range(int(howManyPlayers)):
        doneClickMessage = Text(Point(400,50),'Click screen when done typing in')
        doneClickMessage.draw(win)
        question = "What is the name of player number",i+1,"?"
        askingPlayerName = Text(Point(150,100 + i*20),question)
        askingPlayerName.draw(win)
        inputPlayerName = Entry(Point(350,100 + i*20),10)
        inputPlayerName.draw(win)
        playerName = inputPlayerName.getText()
        playerNameFile.write(playerName + ",")
        doneButtonClick = win.getMouse()
    playerNameFile.close()
    

def howManyPlayerScreen():
    win = GraphWin("How Many Player Screen",400,400)
    win.setBackground("green")
    #fix the main menu button and add it to all of the screens
    """
    mainMenuButton = Rectangle(Point(280,300),Point(320,320))
    mainMenuButton.draw(win)
    mainMenuButtonText = Text(Point(300,310),"MAIN MENU")
    mainMenuButtonText.draw(win)
     if mainMenuButtonClick.getX() > 280 < 320 and mainMenuButtonClick.getY() > 300 < 320:
        win.close()
        startMenu()
    else:
        pass    """
    #mainMenuButtonClick = win.getMouse()
    howManyPlayersOne = Text(Point(200,50),"How Many Players will there be? click screen when done")
    howManyPlayersFile = open("how many players.txt","w")
    howManyPlayersTwo = Entry(Point(200,150),1)
    howManyPlayersGetText = howManyPlayersTwo.getText()
    howManyPlayersFile.write(howManyPlayersGetText)
    howManyPlayersFile.close()
    howManyPlayersOne.draw(win)
    howManyPlayersTwo.draw(win)
    doneButtonPartOne = Rectangle(Point(175,200),Point(225,225))
    doneButtonPartTwo = Text(Point(200,212.5),"DONE")
    doneButtonPartOne.draw(win)
    doneButtonPartTwo.draw(win)
    doneButtonClick = win.getMouse()
    howManyPlayers = howManyPlayersTwo.getText()
    if doneButtonClick.getX() >175 < 225 and doneButtonClick.getY() >200 < 225:
        if howManyPlayers == '2' or howManyPlayers == '3' or howManyPlayers == '4' or howManyPlayers == '5' or howManyPlayers == '6' or howManyPlayers =='7' or howManyPlayers =='8':
            win.close()
            playerNameScreen(howManyPlayers)
        else:
            win2 = GraphWin("Error Screen 1",500,100)
            errorMessageOne = Text(Point(200,20),"Invalid number of players entered")
            errorMessageOne.draw(win2)
            errorMessageTwo = Text(Point(200,50),"Please exit out of this window and try again")
            errorMessageTwo.draw(win2)
            howManyPlayerScreen()
    else:
        win.close()
        howManyPlayerScreen()

def startMenu():
    win = GraphWin("Poker Start Menu",400,400)
    win.setBackground("green")
    title = Text(Point(200,150),"Welcome to Online Poker")
    title.setSize(20)
    title.draw(win)
    startButton = Rectangle(Point(50,200),Point(350,350))
    startButton.setFill("white")
    startButton.draw(win)
    startButtonMessage = Text(Point(200,275),"START")
    startButtonMessage.setSize(25)
    startButtonMessage.draw(win)
    startButtonClick = win.getMouse()
    if startButtonClick.getX() > 50 < 350 and startButtonClick.getY() > 200 < 350:
        win.close()
        howManyPlayerScreen()
    else:
        win.close()
        startMenu()
    
startMenu()



 

