from graphics import *
from random import *

#Create Player Class that has a name, chip amount, and a deck
#Create Card Types (Spade, Diamond, Club, Heart)
    #Within the card types, randomize whether they get 1-10, Ace, King, Queen, or Jack) 
    #Now randomize which color they will be (Red or Black)  
class Player:

    def __init__(self,name):

        self.name = name

        #Create Chip Types(White, Blue, Green, Red, Black)
        self.chips = {"White":[5,10],"Blue":[10,10],"Red":[20,10],"Green":[50,10],"Black":[100,10]}
        self.chipAmount = int(self.chips["White"][1]) + int(self.chips["Blue"][1]) + int(self.chips["Red"][1]) + int(self.chips["Green"][1]) + int(self.chips["Black"][1])
        
        self.cards = {}
        self.cardGraphs = []

    #things = {"card1":["circle",100,100,200],"card2":["square",100,100,200,200]}
    #Try using dictionaries to create store the cards. ^^^

    def generateCard(self,cardNum):
        value = ['2','3','4','5','6','7','8','9','10','King','Queen','Jack','Ace']
        pattern = ['Diamonds','Clubs','Hearts','Spades']
        self.card = []
        self.cardValue = value[randint(0,12)]
        self.cardPattern = pattern[randint(0,3)]
        self.card.append(self.cardValue)
        self.card.append(self.cardPattern)
        self.cards[str(cardNum)] = self.card

        self.cardGraphs.append(self.cardValue + "_of_" + self.cardPattern.lower() + ".gif")
