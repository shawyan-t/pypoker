def crapTards(winner):
    listOfShit = []
    for i in range(3):
        number = int(input("Put some random number here"))
        if number > 10:
            listOfShit.append("NIGGER")
        elif number < 10:
            listOfShit.append("COON")
        elif number < 0:
            listOfShit.append("COTTON PICKER")
    for i in listOfShit:       
        if listOfShit.count("NIGGER") == 2:
            winner = "grape"
            print(winner)
            print()
            return
        elif listOfShit.count("NIGGER") != 2:
            print(winner)
            print()
    print("NIGGERS ARE CANCER TO SOCIETY")
        


def negro():
    winner = "crappy"
    for i in range(3):
        crapTards(winner)
    print("NIGTARDS")
    
    
negro()


